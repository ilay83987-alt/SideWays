const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

ipcMain.handle('pick-build', async () => {
  const res = await dialog.showOpenDialog({
    title: 'Choose the folder of a Fortnite season',
    properties: ['openDirectory']
  });
  return res.canceled ? null : res.filePaths[0];
});

// Starts the game executable found inside the chosen season folder.
ipcMain.handle('play-build', (_event, dir) => {
  if (typeof dir !== 'string') return { ok: false };
  const candidates = [
    'FortniteGame/Binaries/Win64/FortniteClient-Win64-Shipping.exe',
    'FortniteGame/Binaries/Win64/FortniteLauncher.exe'
  ].map((rel) => path.join(dir, rel));
  const exe = candidates.find((p) => fs.existsSync(p));
  if (!exe) return { ok: false };
  try {
    spawn(exe, [], { cwd: path.dirname(exe), detached: true, stdio: 'ignore' }).unref();
    return { ok: true };
  } catch (e) {
    return { ok: false };
  }
});

ipcMain.on('win-min', (e) => BrowserWindow.fromWebContents(e.sender).minimize());
ipcMain.on('win-close', (e) => BrowserWindow.fromWebContents(e.sender).close());

function createWindow() {
  const win = new BrowserWindow({
    width: 1100,
    height: 700,
    minWidth: 900,
    minHeight: 600,
    title: 'SideWays',
    backgroundColor: '#0b0a14',
    autoHideMenuBar: true,
    frame: false,
    icon: path.join(__dirname, 'build', 'icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true
    }
  });
  win.removeMenu();
  // Links such as the Discord invite open in the default browser.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.loadFile('index.html');
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('launcher', {
  pickBuild: () => ipcRenderer.invoke('pick-build'),
  play: (dir) => ipcRenderer.invoke('play-build', dir),
  minimize: () => ipcRenderer.send('win-min'),
  close: () => ipcRenderer.send('win-close')
});

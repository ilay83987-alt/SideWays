@echo off
echo Installing dependencies...
call npm install
echo Building SideWays.exe...
call npm run build
echo Done. Your file is in the "dist" folder.
pause
